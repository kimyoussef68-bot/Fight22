package com.kim.pixelfight;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class GameView extends View {
    static final float W = 1600f, H = 900f, GROUND = 700f;
    static final int INTRO = 0, FIGHT = 1, ROUND_END = 2, MATCH_END = 3;

    static class Fighter {
        float x, y = GROUND, vy, hp = 100f;
        int dir = 1, atkType = 0, wins = 0;
        float atkT, atkDur, hurtT;
        boolean hitDone;

        void reset(float startX, int d) {
            x = startX; y = GROUND; vy = 0; hp = 100f; dir = d;
            atkType = 0; atkT = 0; hurtT = 0; hitDone = false;
        }

        boolean onGround() { return y >= GROUND - 0.5f; }

        void startAttack(int type) {
            atkType = type;
            atkDur = type == 1 ? 0.30f : 0.50f;
            atkT = atkDur;
            hitDone = false;
        }

        void update(float dt, int move, boolean jump, int attack) {
            if (hurtT > 0) hurtT -= dt;
            if (atkT > 0) {
                atkT -= dt;
                if (atkT <= 0) { atkT = 0; atkType = 0; }
            }
            if (hurtT <= 0 && atkT <= 0) {
                x += move * 420f * dt;
                if (jump && onGround()) vy = -1150f;
                if (attack != 0) startAttack(attack);
            }
            vy += 3000f * dt;
            y += vy * dt;
            if (y >= GROUND) { y = GROUND; vy = 0; }
            if (x < 80) x = 80;
            if (x > W - 80) x = W - 80;
        }
    }

    final Fighter p = new Fighter();
    final Fighter e = new Fighter();
    final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Random rnd = new Random();

    int state = INTRO;
    int round = 1;
    float stateT = 0f, roundTime = 60f;
    String banner = "";
    long lastNs = 0;

    // input
    boolean heldLeft, heldRight;
    boolean pressJump;
    int pressAtk;

    // ai
    float aiT = 0f;
    int aiMove = 0;

    // buttons (virtual coordinates)
    final RectF bLeft = new RectF(40, 720, 220, 880);
    final RectF bRight = new RectF(250, 720, 430, 880);
    final RectF bJump = new RectF(1010, 720, 1160, 880);
    final RectF bPunch = new RectF(1190, 720, 1340, 880);
    final RectF bKick = new RectF(1370, 720, 1520, 880);

    float scale = 1f, offX = 0f, offY = 0f;

    public GameView(Context c) {
        super(c);
        startRound();
    }

    void startRound() {
        p.reset(450, 1);
        e.reset(1150, -1);
        roundTime = 60f;
        state = INTRO;
        stateT = 0f;
        banner = "ROUND " + round;
    }

    void newMatch() {
        p.wins = 0; e.wins = 0; round = 1;
        startRound();
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int action = ev.getActionMasked();
        int upIdx = (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP)
                ? ev.getActionIndex() : -1;
        boolean cancel = action == MotionEvent.ACTION_CANCEL;

        if (state == MATCH_END && action == MotionEvent.ACTION_DOWN) {
            newMatch();
            return true;
        }

        heldLeft = false; heldRight = false;
        if (!cancel) {
            for (int i = 0; i < ev.getPointerCount(); i++) {
                if (i == upIdx) continue;
                float vx = (ev.getX(i) - offX) / scale;
                float vy = (ev.getY(i) - offY) / scale;
                if (bLeft.contains(vx, vy)) heldLeft = true;
                if (bRight.contains(vx, vy)) heldRight = true;
                boolean isNew = (action == MotionEvent.ACTION_DOWN)
                        || (action == MotionEvent.ACTION_POINTER_DOWN && i == ev.getActionIndex());
                if (isNew) {
                    if (bJump.contains(vx, vy)) pressJump = true;
                    if (bPunch.contains(vx, vy)) pressAtk = 1;
                    if (bKick.contains(vx, vy)) pressAtk = 2;
                }
            }
        }
        return true;
    }

    void faceEachOther() {
        if (p.atkT <= 0) p.dir = e.x >= p.x ? 1 : -1;
        if (e.atkT <= 0) e.dir = p.x >= e.x ? 1 : -1;
    }

    void aiThink(float dt) {
        aiT -= dt;
        if (aiT > 0) return;
        aiT = 0.18f + rnd.nextFloat() * 0.3f;
        float dist = Math.abs(p.x - e.x);
        int toward = p.x > e.x ? 1 : -1;
        aiMove = 0;
        if (dist > 190) {
            aiMove = toward;
        } else if (dist < 90) {
            aiMove = rnd.nextFloat() < 0.5f ? -toward : 0;
        }
    }

    int aiAttackChoice() {
        float dist = Math.abs(p.x - e.x);
        if (e.atkT > 0 || e.hurtT > 0) return 0;
        if (dist < 190 && rnd.nextFloat() < 0.025f) {
            return (dist < 130 && rnd.nextFloat() < 0.6f) ? 1 : 2;
        }
        return 0;
    }

    void checkHit(Fighter a, Fighter d) {
        if (a.atkType == 0 || a.hitDone) return;
        if (a.atkT > a.atkDur * 0.6f) return; // wind-up
        float reach = a.atkType == 1 ? 130f : 170f;
        float dx = (d.x - a.x) * a.dir;
        if (dx > -20 && dx < reach && Math.abs(d.y - a.y) < 140f) {
            d.hp -= a.atkType == 1 ? 7f : 11f;
            if (d.hp < 0) d.hp = 0;
            d.hurtT = 0.3f;
            d.atkType = 0; d.atkT = 0;
            d.x += a.dir * (a.atkType == 1 ? 30f : 60f);
            a.hitDone = true;
            spawnSpark(d.x, d.y - 110f);
        }
    }

    void endRound(String text, int winner) {
        banner = text;
        if (winner == 1) p.wins++;
        if (winner == 2) e.wins++;
        state = ROUND_END;
        stateT = 0f;
    }

    void update(float dt) {
        stateT += dt;
        if (state == INTRO) {
            if (stateT > 1.5f) { state = FIGHT; stateT = 0f; banner = "FIGHT!"; }
            return;
        }
        if (state == FIGHT) {
            int move = (heldRight ? 1 : 0) - (heldLeft ? 1 : 0);
            boolean j = pressJump; int a = pressAtk;
            pressJump = false; pressAtk = 0;
            faceEachOther();
            p.update(dt, move, j, a);
            aiThink(dt);
            boolean aj = rnd.nextFloat() < 0.004f;
            e.update(dt, aiMove, aj, aiAttackChoice());
            checkHit(p, e);
            checkHit(e, p);
            roundTime -= dt;
            if (e.hp <= 0) endRound("K.O.  You win the round!", 1);
            else if (p.hp <= 0) endRound("K.O.  You lost the round", 2);
            else if (roundTime <= 0) {
                if (p.hp > e.hp) endRound("Time! You win the round", 1);
                else if (e.hp > p.hp) endRound("Time! You lost the round", 2);
                else endRound("Draw", 0);
            }
            return;
        }
        if (state == ROUND_END) {
            p.update(dt, 0, false, 0);
            e.update(dt, 0, false, 0);
            if (stateT > 2.2f) {
                if (p.wins >= 2) { state = MATCH_END; banner = "YOU WIN!"; }
                else if (e.wins >= 2) { state = MATCH_END; banner = "YOU LOSE"; }
                else { round++; startRound(); }
            }
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : (now - lastNs) / 1e9f;
        lastNs = now;
        if (dt > 0.033f) dt = 0.033f;
        update(dt);

        int w = getWidth(), h = getHeight();
        scale = Math.min(w / W, h / H);
        offX = (w - W * scale) / 2f;
        offY = (h - H * scale) / 2f;

        c.drawColor(Color.BLACK);
        c.save();
        c.translate(offX, offY);
        c.scale(scale, scale);
        c.clipRect(0, 0, W, H);

        drawStage(c);

        drawFighter(c, p, 0);
        drawFighter(c, e, 1);
        drawSparks(c, dt);
        drawHud(c);
        drawButtons(c);

        if (state != FIGHT || stateT < 0.8f) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(90f);
            c.drawText(banner, W / 2f, 380f, paint);
            if (state == MATCH_END) {
                paint.setTextSize(48f);
                c.drawText("Tap to play again", W / 2f, 450f, paint);
            }
        }
        c.restore();
        postInvalidateOnAnimation();
    }

    static final String[] IDLE = {
        "................",
        "....HHHHH.......",
        "...HHHHHHH......",
        "...HHSSSSS......",
        "....SSSSSS......",
        "....SSSSS.......",
        ".....SSS........",
        "....BBBBBB......",
        "...BBBBBBBB.....",
        "..SBBBBBBBBS....",
        "..SBBBBBBBBS....",
        "..SBBBBBBBS.....",
        "...BBBBBBB......",
        "....PPPPPP......",
        "....PPPPPP......",
        "....PPPPPPP.....",
        "....PP..PPP.....",
        "....PP...PP.....",
        "....PP...PP.....",
        "....PP...PP.....",
        "...DDD...DDD....",
        "...DDD...DDD...."
    };
    static final String[] PUNCH = {
        "................",
        "....HHHHH.......",
        "...HHHHHHH......",
        "...HHSSSSS......",
        "....SSSSSS......",
        "....SSSSS.......",
        ".....SSS........",
        "....BBBBBB......",
        "...BBBBBBBB.....",
        "...BBBBBBBSSSSSS",
        "...BBBBBBBSSSSSS",
        "...BBBBBBB......",
        "...BBBBBBB......",
        "....PPPPPP......",
        "....PPPPPP......",
        "....PPPPPPP.....",
        "....PP..PPP.....",
        "....PP...PP.....",
        "....PP...PP.....",
        "....PP...PP.....",
        "...DDD...DDD....",
        "...DDD...DDD...."
    };
    static final String[] KICK = {
        "................",
        "....HHHHH.......",
        "...HHHHHHH......",
        "...HHSSSSS......",
        "....SSSSSS......",
        "....SSSSS.......",
        ".....SSS........",
        "....BBBBBB......",
        "...BBBBBBBB.....",
        "..SBBBBBBBBS....",
        "..SBBBBBBBBS....",
        "..SBBBBBBBS.....",
        "...BBBBBBB......",
        "....PPPPPP......",
        "....PPPPPPPPP...",
        "....PPPPPPPPPPDD",
        "....PP......PPDD",
        "....PP..........",
        "....PP..........",
        "....PP..........",
        "...DDD..........",
        "...DDD.........."
    };
    static final String[] JUMP = {
        "................",
        "....HHHHH.......",
        "...HHHHHHH......",
        "...HHSSSSS......",
        "....SSSSSS......",
        "....SSSSS.......",
        ".....SSS........",
        "....BBBBBB......",
        "...BBBBBBBB.....",
        "..SBBBBBBBBS....",
        "..SBBBBBBBBS....",
        "..SBBBBBBBS.....",
        "...BBBBBBB......",
        "....PPPPPP......",
        "....PPPPPPP.....",
        "...PPP..PPP.....",
        "...DDD..DDD.....",
        "................",
        "................",
        "................",
        "................",
        "................"
    };

    static class Spark { float x, y, t; }
    final java.util.ArrayList<Spark> sparks = new java.util.ArrayList<>();

    void spawnSpark(float x, float y) {
        Spark k = new Spark();
        k.x = x; k.y = y; k.t = 0.25f;
        sparks.add(k);
    }

    void drawFighter(Canvas c, Fighter f, int color) {
        String[] spr = IDLE;
        if (f.atkType == 1) spr = PUNCH;
        else if (f.atkType == 2) spr = KICK;
        else if (!f.onGround()) spr = JUMP;
        final int ps = 9;
        int hair, skin = Color.rgb(240, 190, 140), shirt, pants, shoes;
        if (color == 0) {
            hair = Color.rgb(40, 30, 30); shirt = Color.rgb(50, 120, 230);
            pants = Color.rgb(30, 40, 90); shoes = Color.rgb(240, 240, 240);
        } else {
            hair = Color.rgb(200, 40, 40); shirt = Color.rgb(220, 50, 50);
            pants = Color.rgb(60, 30, 30); shoes = Color.rgb(250, 200, 40);
        }
        boolean flash = f.hurtT > 0 && ((int) (f.hurtT * 30) % 2 == 0);
        paint.setStyle(Paint.Style.FILL);
        float top = f.y - spr.length * ps;
        // shadow
        paint.setColor(Color.argb(90, 0, 0, 0));
        c.drawRect(f.x - 70, GROUND - 4, f.x + 70, GROUND + 6, paint);
        for (int r = 0; r < spr.length; r++) {
            String row = spr[r];
            for (int col = 0; col < 16 && col < row.length(); col++) {
                char ch = row.charAt(col);
                if (ch == '.') continue;
                int cc;
                switch (ch) {
                    case 'H': cc = hair; break;
                    case 'S': cc = skin; break;
                    case 'B': cc = shirt; break;
                    case 'P': cc = pants; break;
                    default: cc = shoes; break;
                }
                if (flash) cc = Color.WHITE;
                paint.setColor(cc);
                float px = f.dir > 0 ? f.x + (col - 6) * ps : f.x - (col - 6) * ps - ps;
                c.drawRect(px, top + r * ps, px + ps, top + (r + 1) * ps, paint);
            }
        }
    }

    void drawSparks(Canvas c, float dt) {
        paint.setStyle(Paint.Style.FILL);
        for (int i = sparks.size() - 1; i >= 0; i--) {
            Spark k = sparks.get(i);
            k.t -= dt;
            if (k.t <= 0) { sparks.remove(i); continue; }
            float g = (0.25f - k.t) * 400f;
            paint.setColor(Color.rgb(255, 230, 60));
            c.drawRect(k.x - 9, k.y - 9, k.x + 9, k.y + 9, paint);
            paint.setColor(Color.WHITE);
            c.drawRect(k.x - 27 - g, k.y - 4, k.x - 9 - g, k.y + 4, paint);
            c.drawRect(k.x + 9 + g, k.y - 4, k.x + 27 + g, k.y + 4, paint);
            c.drawRect(k.x - 4, k.y - 27 - g, k.x + 4, k.y - 9 - g, paint);
            c.drawRect(k.x - 4, k.y + 9 + g, k.x + 4, k.y + 27 + g, paint);
        }
    }

    void drawStage(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        int[] sky = { Color.rgb(25, 20, 60), Color.rgb(55, 30, 90), Color.rgb(100, 45, 110),
                Color.rgb(160, 70, 110), Color.rgb(230, 120, 100) };
        float bandH = GROUND / sky.length;
        for (int i = 0; i < sky.length; i++) {
            paint.setColor(sky[i]);
            c.drawRect(0, i * bandH, W, (i + 1) * bandH + 1, paint);
        }
        paint.setColor(Color.rgb(255, 230, 150));
        c.drawRect(1260, 120, 1380, 240, paint);
        // city skyline
        paint.setColor(Color.rgb(20, 15, 40));
        int[] hs = { 220, 300, 180, 360, 260, 200, 320, 240, 380, 210, 280, 190, 340, 250, 230, 300 };
        for (int i = 0; i < hs.length; i++) {
            float bx = i * 100f;
            c.drawRect(bx, GROUND - hs[i], bx + 90, GROUND, paint);
        }
        paint.setColor(Color.rgb(255, 220, 90));
        for (int i = 0; i < hs.length; i++) {
            for (int wy = 0; wy < hs[i] - 40; wy += 50) {
                if (((i * 7 + wy / 50) % 3) == 0) continue;
                c.drawRect(i * 100f + 15, GROUND - hs[i] + 20 + wy, i * 100f + 35, GROUND - hs[i] + 40 + wy, paint);
                c.drawRect(i * 100f + 55, GROUND - hs[i] + 20 + wy, i * 100f + 75, GROUND - hs[i] + 40 + wy, paint);
            }
        }
        // floor tiles
        for (int i = 0; i < 32; i++) {
            paint.setColor(i % 2 == 0 ? Color.rgb(90, 70, 60) : Color.rgb(70, 52, 46));
            c.drawRect(i * 50f, GROUND, i * 50f + 50, GROUND + 60, paint);
            paint.setColor(i % 2 == 0 ? Color.rgb(60, 45, 40) : Color.rgb(80, 60, 52));
            c.drawRect(i * 50f, GROUND + 60, i * 50f + 50, H, paint);
        }
    }

    void drawBar(Canvas c, float x, float y, float w, float hp, int color, boolean rightAlign) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.DKGRAY);
        c.drawRect(x, y, x + w, y + 36, paint);
        paint.setColor(color);
        float fw = w * hp / 100f;
        if (rightAlign) c.drawRect(x + w - fw, y, x + w, y + 36, paint);
        else c.drawRect(x, y, x + fw, y + 36, paint);
    }

    void drawHud(Canvas c) {
        drawBar(c, 40, 40, 620, p.hp, Color.rgb(90, 180, 255), false);
        drawBar(c, 940, 40, 620, e.hp, Color.rgb(255, 100, 100), true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(56f);
        c.drawText(String.valueOf((int) Math.max(0, Math.ceil(roundTime))), W / 2f, 80f, paint);
        paint.setTextSize(36f);
        paint.setTextAlign(Paint.Align.LEFT);
        c.drawText("YOU  wins: " + p.wins, 40, 110, paint);
        paint.setTextAlign(Paint.Align.RIGHT);
        c.drawText("CPU  wins: " + e.wins, 1560, 110, paint);
    }

    void drawButton(Canvas c, RectF r, String t, boolean on) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(on ? Color.argb(170, 255, 255, 255) : Color.argb(90, 255, 255, 255));
        c.drawRoundRect(r, 24, 24, paint);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(44f);
        c.drawText(t, r.centerX(), r.centerY() + 15f, paint);
    }

    void drawButtons(Canvas c) {
        drawButton(c, bLeft, "<", heldLeft);
        drawButton(c, bRight, ">", heldRight);
        drawButton(c, bJump, "JUMP", false);
        drawButton(c, bPunch, "PUNCH", false);
        drawButton(c, bKick, "KICK", false);
    }
}
