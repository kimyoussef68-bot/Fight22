// player.js - Fighter entity, physics, movement states, attack cancels, and hurtbox/pushbox logic
(function (IF) {
  'use strict';

  class Fighter {
    constructor(playerIndex, config, startX, groundY) {
      this.playerIndex = playerIndex; // 0 = P1, 1 = P2/CPU
      this.config = config;
      this.groundY = groundY;
      this.reset(startX, playerIndex === 0 ? 1 : -1);
    }

    reset(startX, facing) {
      this.x = startX;
      this.y = this.groundY;
      this.vx = 0;
      this.vy = 0;
      this.facing = facing;
      this.hp = this.config.maxHp;
      this.displayHp = this.config.maxHp;
      this.energy = 25; // Start with 25% bar for immediate special access
      this.state = 'idle'; // idle, walkF, walkB, run, crouch, jump, block, attack, hitstun, knockdown, victory, ko
      this.jumpsUsed = 0;
      this.currentMove = null;
      this.moveFrame = 0;
      this.moveFrameAccum = 0;
      this.moveHasHit = false;
      this.specialFired = false;
      this.stunFrames = 0;
      this.stunAccum = 0;
      this.invulnFrames = 0;
      this.hitFlashTimer = 0;
      this.comboCount = 0;
      this.comboTimer = 0;
      this.comboTaken = 0;
      this.isBlockingInput = false;
      this.roundWins = this.roundWins || 0;
    }

    addEnergy(amount) {
      this.energy = Math.max(0, Math.min(100, this.energy + amount));
    }

    isGrounded() {
      return this.y >= this.groundY - 0.5;
    }

    getHurtbox() {
      const crouching = this.state === 'crouch';
      const w = 64;
      const h = crouching ? 108 : 168;
      return { x: this.x - w * 0.5, y: this.y - h, w, h };
    }

    getPushbox() {
      return { x: this.x - 28, y: this.y - 140, w: 56, h: 140 };
    }

    canBlockAttack(attacker) {
      if (this.state === 'attack' || this.state === 'hitstun' || this.state === 'knockdown' || this.state === 'ko') {
        return false;
      }
      // Blocking if holding explicit block OR holding away from attacker on ground
      if (!this.isGrounded()) return false;
      return this.isBlockingInput;
    }

    enterBlockstun(frames, pushVx) {
      this.state = 'block';
      this.stunFrames = frames;
      this.stunAccum = 0;
      this.vx = pushVx;
      this.currentMove = null;
    }

    enterHitstun(frames, knockVx, launchVy) {
      this.currentMove = null;
      this.hitFlashTimer = 0.14;
      this.vx = knockVx;
      if (launchVy < 0) {
        this.vy = launchVy;
        this.y = Math.min(this.y, this.groundY - 2);
      }
      if (this.hp <= 0) {
        this.state = 'ko';
        this.stunFrames = 999;
      } else if (launchVy <= -240) {
        this.state = 'knockdown';
        this.stunFrames = frames + 14;
        this.stunAccum = 0;
      } else {
        this.state = 'hitstun';
        this.stunFrames = frames;
        this.stunAccum = 0;
      }
    }

    startAttack(moveKey, effects, audio) {
      const move = IF.MOVES[moveKey];
      if (!move) return false;
      if (move.energyCost && this.energy < move.energyCost) return false;

      // Cancel rules: allow cancelling light -> heavy -> special -> super on hit!
      if (this.state === 'attack') {
        if (!this.moveHasHit) return false;
        const cur = this.currentMove;
        const canCancel =
          (cur === IF.MOVES.lp && (moveKey === 'hp' || moveKey === 'lk' || moveKey === 'hk' || moveKey === 'special' || moveKey === 'super')) ||
          (cur === IF.MOVES.lk && (moveKey === 'hk' || moveKey === 'hp' || moveKey === 'special' || moveKey === 'super')) ||
          ((cur === IF.MOVES.hp || cur === IF.MOVES.hk) && (moveKey === 'special' || moveKey === 'super')) ||
          (cur === IF.MOVES.special && moveKey === 'super');
        if (!canCancel) return false;
      } else if (this.state === 'hitstun' || this.state === 'knockdown' || this.state === 'ko' || this.state === 'victory') {
        return false;
      }

      if (move.energyCost) this.addEnergy(-move.energyCost);
      this.state = 'attack';
      this.currentMove = move;
      this.moveFrame = 0;
      this.moveFrameAccum = 0;
      this.moveHasHit = false;
      this.specialFired = false;

      if (move.isSuper) {
        this.invulnFrames = 18;
        effects.triggerSuperFreeze(this, 0.44);
        effects.spawnText(this.x, this.y - 190, this.config.superName + '!', this.config.colors.aura, 1.35);
        audio.playSuper();
      } else if (move.isSpecial) {
        effects.spawnText(this.x, this.y - 182, this.config.specialName, this.config.colors.aura, 0.95);
        audio.playSpecial();
      } else {
        audio.playWhoosh(move.heavy);
      }
      return true;
    }

    update(dt, input, opponent, effects, audio, arenaMinX, arenaMaxX, canAct) {
      // Smooth delayed red health bar drain
      if (this.displayHp > this.hp) {
        this.displayHp = Math.max(this.hp, this.displayHp - dt * 360);
      } else {
        this.displayHp = this.hp;
      }

      if (this.hitFlashTimer > 0) this.hitFlashTimer = Math.max(0, this.hitFlashTimer - dt);
      if (this.invulnFrames > 0) this.invulnFrames = Math.max(0, this.invulnFrames - dt * 60);

      if (this.comboTimer > 0) {
        this.comboTimer -= dt;
        if (this.comboTimer <= 0) this.comboCount = 0;
      }

      // Auto-face opponent when grounded and not mid-attack or stunned
      if (opponent && this.isGrounded() && (this.state === 'idle' || this.state === 'walkF' || this.state === 'walkB' || this.state === 'crouch' || this.state === 'block')) {
        this.facing = opponent.x >= this.x ? 1 : -1;
      }

      // Holding away or explicit block button
      const holdingAway = (this.facing === 1 && input.left && !input.right) || (this.facing === -1 && input.right && !input.left);
      this.isBlockingInput = canAct && (input.block || holdingAway);

      // Handle stun / blockstun / knockdown / KO
      if (this.state === 'hitstun' || this.state === 'block' || this.state === 'knockdown' || this.state === 'ko') {
        this.stunAccum += dt * 60;
        while (this.stunAccum >= 1 && this.stunFrames > 0) {
          this.stunAccum -= 1;
          this.stunFrames -= 1;
        }
        // Friction
        this.vx *= Math.pow(0.06, dt);
        if (this.stunFrames <= 0 && this.state !== 'ko' && this.isGrounded()) {
          if (this.state === 'knockdown') {
            this.invulnFrames = 20; // Wakeup invulnerability
          }
          this.state = 'idle';
          this.comboTaken = 0;
        }
      } else if (this.state === 'victory') {
        this.vx *= Math.pow(0.04, dt);
      } else if (this.state === 'attack' && this.currentMove) {
        const m = this.currentMove;
        this.moveFrameAccum += dt * 60;
        while (this.moveFrameAccum >= 1) {
          this.moveFrameAccum -= 1;
          this.moveFrame += 1;
        }

        // Trigger character-specific special/super movement or projectile on startup frame
        if (!this.specialFired && this.moveFrame >= m.startup) {
          this.specialFired = true;
          if (m.isSpecial) {
            if (this.config.specialType === 'projectile') {
              effects.spawnProjectile({
                owner: this,
                x: this.x + this.facing * 68,
                y: this.y - 118,
                vx: this.facing * 660,
                radius: 26,
                damage: 88,
                chipDamage: 18,
                color: this.config.colors.aura,
                isSuper: false,
                hitsLeft: 1
              });
            } else if (this.config.specialType === 'dash_strike') {
              this.vx = this.facing * 680;
              effects.spawnDust(this.x, this.groundY, this.facing, 10);
            } else if (this.config.specialType === 'rising_upper') {
              this.vx = this.facing * 240;
              this.vy = -580;
              this.invulnFrames = 10;
              effects.spawnDust(this.x, this.groundY, this.facing, 10);
            }
          } else if (m.isSuper) {
            if (this.config.superType === 'dragon_beam') {
              effects.spawnProjectile({
                owner: this,
                x: this.x + this.facing * 75,
                y: this.y - 118,
                vx: this.facing * 820,
                radius: 46,
                damage: 95,
                chipDamage: 22,
                color: this.config.colors.aura,
                isSuper: true,
                hitsLeft: 3
              });
            } else if (this.config.superType === 'flurry_surge') {
              this.vx = this.facing * 820;
            } else if (this.config.superType === 'shockwave_slam') {
              this.vx = this.facing * 420;
              effects.spawnRing(this.x + this.facing * 80, this.groundY - 10, this.config.colors.aura, 220, 0.4);
            }
          }
        }

        // Allow attack cancels if hit landed
        if (canAct) {
          if (input.superPressed) this.startAttack('super', effects, audio);
          else if (input.specialPressed) this.startAttack('special', effects, audio);
          else if (input.hpPressed) this.startAttack('hp', effects, audio);
          else if (input.hkPressed) this.startAttack('hk', effects, audio);
          else if (input.lpPressed) this.startAttack('lp', effects, audio);
          else if (input.lkPressed) this.startAttack('lk', effects, audio);
        }

        if (this.isGrounded()) this.vx *= Math.pow(0.05, dt);

        if (this.moveFrame >= m.startup + m.active + m.recovery) {
          this.currentMove = null;
          this.state = this.isGrounded() ? 'idle' : 'jump';
        }
      } else if (canAct) {
        // Check attack inputs first (priority: Super > Special > Heavy > Light)
        let attacked = false;
        if (input.superPressed) attacked = this.startAttack('super', effects, audio);
        else if (input.specialPressed) attacked = this.startAttack('special', effects, audio);
        else if (input.hpPressed) attacked = this.startAttack('hp', effects, audio);
        else if (input.hkPressed) attacked = this.startAttack('hk', effects, audio);
        else if (input.lpPressed) attacked = this.startAttack('lp', effects, audio);
        else if (input.lkPressed) attacked = this.startAttack('lk', effects, audio);

        if (!attacked) {
          // Jump & Double Jump
          if (input.jumpPressed && this.jumpsUsed < 2) {
            const isDouble = !this.isGrounded() || this.jumpsUsed > 0;
            this.vy = isDouble ? this.config.doubleJumpVel : this.config.jumpVel;
            this.jumpsUsed += 1;
            this.state = 'jump';
            if (!isDouble) effects.spawnDust(this.x, this.groundY, 0, 8);
            else effects.spawnRing(this.x, this.y - 10, this.config.colors.aura, 48, 0.2);
            audio.playJump(isDouble);
          }

          const moveDir = (input.right ? 1 : 0) - (input.left ? 1 : 0);

          if (this.isGrounded()) {
            if (input.block) {
              this.state = 'block';
              this.vx = 0;
            } else if (input.down) {
              this.state = 'crouch';
              this.vx = 0;
            } else if (moveDir !== 0) {
              const forward = moveDir === this.facing;
              if (forward && input.run) {
                this.state = 'run';
                this.vx = moveDir * this.config.runSpeed;
              } else {
                this.state = forward ? 'walkF' : 'walkB';
                this.vx = moveDir * (forward ? this.config.walkSpeed : this.config.backSpeed);
              }
            } else {
              this.state = 'idle';
              this.vx = 0;
            }
          } else {
            // Air control
            this.state = 'jump';
            if (moveDir !== 0) {
              this.vx += moveDir * 950 * dt;
              const maxAir = this.config.walkSpeed * 1.15;
              this.vx = Math.max(-maxAir, Math.min(maxAir, this.vx));
            }
          }
        }
      } else {
        this.vx *= Math.pow(0.05, dt);
        if (this.isGrounded() && this.state !== 'ko' && this.state !== 'victory') this.state = 'idle';
      }

      // Gravity & vertical integration
      if (!this.isGrounded() || this.vy < 0) {
        this.vy += this.config.gravity * dt;
        this.y += this.vy * dt;
        if (this.y >= this.groundY) {
          this.y = this.groundY;
          this.vy = 0;
          this.jumpsUsed = 0;
          effects.spawnDust(this.x, this.groundY, 0, 6);
          if (this.state === 'jump') this.state = 'idle';
        }
      }

      // Horizontal integration & arena bounds
      this.x += this.vx * dt;
      this.x = Math.max(arenaMinX, Math.min(arenaMaxX, this.x));
    }
  }

  // Separate overlapping fighters so they can't stand inside each other
  function resolvePushboxes(p1, p2, minX, maxX) {
    const a = p1.getPushbox();
    const b = p2.getPushbox();
    if (a.y + a.h <= b.y || b.y + b.h <= a.y) return;
    const overlapX = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
    if (overlapX > 0) {
      const push = overlapX * 0.52;
      if (p1.x <= p2.x) {
        p1.x = Math.max(minX, p1.x - push);
        p2.x = Math.min(maxX, p2.x + push);
      } else {
        p1.x = Math.min(maxX, p1.x + push);
        p2.x = Math.max(minX, p2.x - push);
      }
    }
  }

  IF.Fighter = Fighter;
  IF.resolvePushboxes = resolvePushboxes;
})(window.IronFang = window.IronFang || {});
