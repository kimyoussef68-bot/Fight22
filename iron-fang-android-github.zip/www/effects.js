// effects.js - Particle bursts, hit sparks, shockwaves, projectiles, screen shake, and floating text
(function (IF) {
  'use strict';

  class EffectsManager {
    constructor() {
      this.reset();
    }

    reset() {
      this.particles = [];
      this.rings = [];
      this.texts = [];
      this.projectiles = [];
      this.shakeMag = 0;
      this.shakeTime = 0;
      this.flashAlpha = 0;
      this.flashColor = '#ffffff';
      this.superFreezeTimer = 0;
      this.superFlashOwner = null;
    }

    addShake(magnitude, duration) {
      this.shakeMag = Math.max(this.shakeMag, magnitude);
      this.shakeTime = Math.max(this.shakeTime, duration);
    }

    addFlash(color, alpha) {
      this.flashColor = color;
      this.flashAlpha = Math.max(this.flashAlpha, alpha);
    }

    triggerSuperFreeze(owner, duration) {
      this.superFreezeTimer = duration;
      this.superFlashOwner = owner;
      this.addFlash(owner.config.colors.aura, 0.55);
      this.addShake(14, 0.35);
      this.spawnRing(owner.x, owner.y - 95, owner.config.colors.aura, 240, 0.42);
      this.spawnHitSparks(owner.x, owner.y - 95, owner.config.colors.aura, 28, true);
    }

    spawnHitSparks(x, y, color, count, heavy) {
      for (let i = 0; i < count; i++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = (heavy ? 240 : 150) + Math.random() * (heavy ? 480 : 280);
        this.particles.push({
          x, y,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd,
          life: 0.22 + Math.random() * 0.26,
          maxLife: 0.48,
          size: (heavy ? 5 : 3) + Math.random() * 4,
          color: i % 3 === 0 ? '#ffffff' : color,
          gravity: 520,
          streak: true
        });
      }
      this.spawnRing(x, y, color, heavy ? 95 : 55, heavy ? 0.24 : 0.16);
    }

    spawnBlockSparks(x, y) {
      for (let i = 0; i < 12; i++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = 140 + Math.random() * 240;
        this.particles.push({
          x, y,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd,
          life: 0.18 + Math.random() * 0.15,
          maxLife: 0.33,
          size: 3 + Math.random() * 3,
          color: i % 2 === 0 ? '#6ce5ff' : '#ffffff',
          gravity: 200,
          streak: true
        });
      }
      this.spawnRing(x, y, '#6ce5ff', 68, 0.18);
    }

    spawnDust(x, y, dir, count = 7) {
      for (let i = 0; i < count; i++) {
        this.particles.push({
          x: x + (Math.random() - 0.5) * 28,
          y: y - 4,
          vx: -dir * (40 + Math.random() * 110) + (Math.random() - 0.5) * 50,
          vy: -30 - Math.random() * 80,
          life: 0.28 + Math.random() * 0.24,
          maxLife: 0.52,
          size: 7 + Math.random() * 9,
          color: 'rgba(215, 222, 235, 0.55)',
          gravity: 120,
          streak: false
        });
      }
    }

    spawnRing(x, y, color, maxRadius, duration) {
      this.rings.push({ x, y, color, r: 10, maxR: maxRadius, life: duration, maxLife: duration });
    }

    spawnText(x, y, text, color, scale = 1) {
      this.texts.push({ x, y, text, color, scale, life: 0.72, maxLife: 0.72, vy: -72 });
    }

    spawnProjectile(opts) {
      this.projectiles.push({
        owner: opts.owner,
        x: opts.x,
        y: opts.y,
        vx: opts.vx,
        radius: opts.radius || 26,
        damage: opts.damage || 85,
        chipDamage: opts.chipDamage || 16,
        color: opts.color || '#ff5522',
        coreColor: '#ffffff',
        isSuper: !!opts.isSuper,
        hitsLeft: opts.hitsLeft || 1,
        hitCooldown: 0,
        life: opts.life || 2.2
      });
    }

    update(dt, worldW) {
      if (this.shakeTime > 0) {
        this.shakeTime = Math.max(0, this.shakeTime - dt);
        if (this.shakeTime === 0) this.shakeMag = 0;
      }
      if (this.flashAlpha > 0) {
        this.flashAlpha = Math.max(0, this.flashAlpha - dt * 2.2);
      }
      if (this.superFreezeTimer > 0) {
        this.superFreezeTimer = Math.max(0, this.superFreezeTimer - dt);
      }

      for (let i = this.particles.length - 1; i >= 0; i--) {
        const p = this.particles[i];
        p.life -= dt;
        if (p.life <= 0) {
          this.particles.splice(i, 1);
          continue;
        }
        p.vy += p.gravity * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
      }

      for (let i = this.rings.length - 1; i >= 0; i--) {
        const r = this.rings[i];
        r.life -= dt;
        if (r.life <= 0) {
          this.rings.splice(i, 1);
          continue;
        }
        const t = 1 - r.life / r.maxLife;
        r.r = 10 + (r.maxR - 10) * (1 - Math.pow(1 - t, 3));
      }

      for (let i = this.texts.length - 1; i >= 0; i--) {
        const t = this.texts[i];
        t.life -= dt;
        if (t.life <= 0) {
          this.texts.splice(i, 1);
          continue;
        }
        t.y += t.vy * dt;
        t.vy *= 0.94;
      }

      for (let i = this.projectiles.length - 1; i >= 0; i--) {
        const pr = this.projectiles[i];
        pr.life -= dt;
        if (pr.hitCooldown > 0) pr.hitCooldown -= dt;
        pr.x += pr.vx * dt;
        // Trail particles
        if (Math.random() < 0.7) {
          this.particles.push({
            x: pr.x - Math.sign(pr.vx) * pr.radius * 0.6,
            y: pr.y + (Math.random() - 0.5) * pr.radius * 0.9,
            vx: -pr.vx * 0.15,
            vy: (Math.random() - 0.5) * 40,
            life: 0.18,
            maxLife: 0.18,
            size: pr.isSuper ? 9 : 5,
            color: pr.color,
            gravity: 0,
            streak: false
          });
        }
        if (pr.life <= 0 || pr.x < -120 || pr.x > worldW + 120 || pr.hitsLeft <= 0) {
          this.projectiles.splice(i, 1);
        }
      }
    }

    getShakeOffset() {
      if (this.shakeTime <= 0 || this.shakeMag <= 0) return { x: 0, y: 0 };
      const amt = this.shakeMag * Math.min(1, this.shakeTime * 5);
      return {
        x: (Math.random() - 0.5) * 2 * amt,
        y: (Math.random() - 0.5) * 2 * amt
      };
    }

    render(ctx, w, h) {
      // Super freeze dramatic backdrop dim & speedlines
      if (this.superFreezeTimer > 0 && this.superFlashOwner) {
        ctx.save();
        ctx.fillStyle = 'rgba(6, 8, 20, 0.58)';
        ctx.fillRect(0, 0, w, h);
        const ox = this.superFlashOwner.x;
        const oy = this.superFlashOwner.y - 95;
        ctx.strokeStyle = this.superFlashOwner.config.colors.aura;
        ctx.globalAlpha = 0.45;
        ctx.lineWidth = 3;
        for (let i = 0; i < 24; i++) {
          const ang = (i / 24) * Math.PI * 2 + this.superFreezeTimer * 4;
          ctx.beginPath();
          ctx.moveTo(ox + Math.cos(ang) * 70, oy + Math.sin(ang) * 70);
          ctx.lineTo(ox + Math.cos(ang) * 900, oy + Math.sin(ang) * 900);
          ctx.stroke();
        }
        ctx.restore();
      }

      // Shockwave rings
      for (let i = 0; i < this.rings.length; i++) {
        const r = this.rings[i];
        const a = Math.max(0, r.life / r.maxLife);
        ctx.save();
        ctx.globalAlpha = a * 0.85;
        ctx.strokeStyle = r.color;
        ctx.lineWidth = 4 * a + 1.5;
        ctx.beginPath();
        ctx.arc(r.x, r.y, r.r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Projectiles
      for (let i = 0; i < this.projectiles.length; i++) {
        const pr = this.projectiles[i];
        ctx.save();
        const dir = Math.sign(pr.vx) || 1;
        // Energy tail
        const grad = ctx.createRadialGradient(pr.x, pr.y, pr.radius * 0.2, pr.x, pr.y, pr.radius * 1.7);
        grad.addColorStop(0, pr.coreColor);
        grad.addColorStop(0.45, pr.color);
        grad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.ellipse(pr.x - dir * pr.radius * 0.5, pr.y, pr.radius * 1.85, pr.radius * 1.15, 0, 0, Math.PI * 2);
        ctx.fill();
        // Bright core
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(pr.x + dir * pr.radius * 0.25, pr.y, pr.radius * 0.48, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Particles
      for (let i = 0; i < this.particles.length; i++) {
        const p = this.particles[i];
        const a = Math.max(0, p.life / p.maxLife);
        ctx.save();
        ctx.globalAlpha = a;
        if (p.streak) {
          ctx.strokeStyle = p.color;
          ctx.lineWidth = p.size * 0.65;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 0.032, p.y - p.vy * 0.032);
          ctx.stroke();
        } else {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (0.4 + 0.6 * a), 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // Floating combat callouts
      for (let i = 0; i < this.texts.length; i++) {
        const t = this.texts[i];
        const a = Math.min(1, (t.life / t.maxLife) * 1.6);
        ctx.save();
        ctx.globalAlpha = a;
        ctx.font = `900 ${Math.round(24 * t.scale)}px "Impact", "Arial Black", sans-serif`;
        ctx.textAlign = 'center';
        ctx.lineWidth = 5;
        ctx.strokeStyle = '#090b12';
        ctx.strokeText(t.text, t.x, t.y);
        ctx.fillStyle = t.color;
        ctx.fillText(t.text, t.x, t.y);
        ctx.restore();
      }

      // Screen flash overlay
      if (this.flashAlpha > 0.01) {
        ctx.save();
        ctx.globalAlpha = this.flashAlpha;
        ctx.fillStyle = this.flashColor;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
      }
    }
  }

  IF.EffectsManager = EffectsManager;
})(window.IronFang = window.IronFang || {});
