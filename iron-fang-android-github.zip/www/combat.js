// combat.js - Frame-data move table, hitboxes, hurtboxes, hit/block stun, combo scaling, and collision resolution
(function (IF) {
  'use strict';

  // All frame timings are in 60Hz arcade frames
  const MOVES = {
    lp: {
      name: 'Light Punch',
      poseKey: 'lp',
      startup: 4,
      active: 4,
      recovery: 8,
      damage: 45,
      chipDamage: 0,
      hitstun: 14,
      blockstun: 9,
      knockback: 210,
      launchY: 0,
      energyGain: 7,
      hitstop: 4,
      heavy: false,
      low: false,
      hitbox: { x: 24, y: -148, w: 78, h: 34 }
    },
    hp: {
      name: 'Heavy Punch',
      poseKey: 'hp',
      startup: 8,
      active: 5,
      recovery: 16,
      damage: 95,
      chipDamage: 6,
      hitstun: 22,
      blockstun: 14,
      knockback: 390,
      launchY: -120,
      energyGain: 13,
      hitstop: 8,
      heavy: true,
      low: false,
      hitbox: { x: 28, y: -152, w: 96, h: 42 }
    },
    lk: {
      name: 'Light Kick',
      poseKey: 'lk',
      startup: 5,
      active: 4,
      recovery: 10,
      damage: 55,
      chipDamage: 0,
      hitstun: 15,
      blockstun: 10,
      knockback: 240,
      launchY: 0,
      energyGain: 8,
      hitstop: 5,
      heavy: false,
      low: true,
      hitbox: { x: 20, y: -88, w: 88, h: 40 }
    },
    hk: {
      name: 'Heavy Kick',
      poseKey: 'hk',
      startup: 10,
      active: 6,
      recovery: 18,
      damage: 112,
      chipDamage: 8,
      hitstun: 26,
      blockstun: 16,
      knockback: 460,
      launchY: -240,
      energyGain: 15,
      hitstop: 9,
      heavy: true,
      low: false,
      hitbox: { x: 26, y: -146, w: 104, h: 52 }
    },
    special: {
      name: 'Special Move',
      poseKey: 'special',
      startup: 10,
      active: 8,
      recovery: 18,
      damage: 115,
      chipDamage: 20,
      hitstun: 26,
      blockstun: 16,
      knockback: 480,
      launchY: -280,
      energyGain: 14,
      energyCost: 25,
      hitstop: 10,
      heavy: true,
      isSpecial: true,
      low: false,
      hitbox: { x: 24, y: -155, w: 112, h: 64 }
    },
    super: {
      name: 'SUPER ART',
      poseKey: 'super',
      startup: 12,
      active: 14,
      recovery: 22,
      damage: 235,
      chipDamage: 48,
      hitstun: 36,
      blockstun: 22,
      knockback: 640,
      launchY: -420,
      energyGain: 0,
      energyCost: 100,
      hitstop: 14,
      heavy: true,
      isSuper: true,
      low: false,
      hitbox: { x: 20, y: -168, w: 148, h: 92 }
    }
  };

  function rectsOverlap(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  function getWorldHitbox(attacker) {
    if (attacker.state !== 'attack' || !attacker.currentMove) return null;
    const m = attacker.currentMove;
    if (attacker.moveFrame < m.startup || attacker.moveFrame >= m.startup + m.active) return null;
    // Projectile-type specials don't need melee hitbox except close range
    const hb = m.hitbox;
    const x = attacker.facing === 1 ? attacker.x + hb.x : attacker.x - hb.x - hb.w;
    const y = attacker.y + hb.y;
    return { x, y, w: hb.w, h: hb.h };
  }

  function applyHit(attacker, defender, move, effects, audio, isProjectile) {
    // Check if defender is blocking (holding away or block button while facing attacker)
    const canBlock = defender.canBlockAttack(attacker);
    const hitX = (attacker.x + defender.x) * 0.5;
    const hitY = defender.y - (defender.state === 'crouch' ? 75 : 118);

    if (canBlock) {
      const chip = move.chipDamage || 0;
      if (chip > 0 && defender.hp > 1) {
        defender.hp = Math.max(1, defender.hp - chip);
      }
      defender.enterBlockstun(move.blockstun || 10, attacker.facing * (move.knockback * 0.45));
      attacker.addEnergy((move.energyGain || 6) * 0.5);
      defender.addEnergy(5);
      effects.spawnBlockSparks(hitX, hitY);
      effects.spawnText(hitX, hitY - 26, chip > 0 ? `GUARD -${chip}` : 'GUARD', '#6ce5ff', 0.82);
      effects.addShake(move.heavy ? 5 : 2.5, 0.1);
      audio.playBlock();
      return { hitstop: Math.max(3, Math.floor((move.hitstop || 5) * 0.6)), blocked: true };
    }

    // Combo scaling (prevents infinite 100% touch-of-death while rewarding real combos)
    const comboCount = defender.comboTaken + 1;
    const scale = Math.max(0.42, 1 - (comboCount - 1) * 0.11);
    const powerFactor = attacker.config.stats.power / 82;
    const defFactor = 82 / defender.config.stats.defense;
    const finalDamage = Math.max(10, Math.round(move.damage * scale * powerFactor * defFactor));

    defender.hp = Math.max(0, defender.hp - finalDamage);
    defender.comboTaken = comboCount;
    attacker.comboCount = comboCount;
    attacker.comboTimer = 1.45;
    attacker.addEnergy(move.energyGain || 8);
    defender.addEnergy(Math.round(finalDamage * 0.09));

    const knockX = (isProjectile ? Math.sign(move.projVx || attacker.facing) : attacker.facing) * move.knockback;
    const launchY = defender.hp <= 0 ? -360 : (move.launchY || 0);
    defender.enterHitstun(move.hitstun || 16, knockX, launchY);

    effects.spawnHitSparks(hitX, hitY, attacker.config.colors.aura, move.isSuper ? 30 : (move.heavy ? 18 : 10), move.heavy);
    effects.spawnText(hitX, hitY - 28, `-${finalDamage}`, move.isSuper ? '#ffd147' : (move.heavy ? '#ff6b4a' : '#ffffff'), move.isSuper ? 1.35 : (move.heavy ? 1.05 : 0.85));
    effects.addShake(move.isSuper ? 16 : (move.heavy ? 9 : 4), move.isSuper ? 0.3 : (move.heavy ? 0.16 : 0.08));
    if (move.isSuper) effects.addFlash(attacker.config.colors.aura, 0.35);
    audio.playHit(move.heavy || move.isSuper);

    return { hitstop: move.hitstop || 5, blocked: false, damage: finalDamage };
  }

  function resolveCombat(p1, p2, effects, audio) {
    let maxHitstop = 0;

    // 1. Melee attacks
    const pairs = [[p1, p2], [p2, p1]];
    for (let i = 0; i < pairs.length; i++) {
      const [atk, def] = pairs[i];
      if (atk.state === 'attack' && atk.currentMove && !atk.moveHasHit && def.invulnFrames <= 0) {
        const hb = getWorldHitbox(atk);
        const hurt = def.getHurtbox();
        if (hb && rectsOverlap(hb, hurt)) {
          atk.moveHasHit = true;
          const res = applyHit(atk, def, atk.currentMove, effects, audio, false);
          if (res.hitstop > maxHitstop) maxHitstop = res.hitstop;
        }
      }
    }

    // 2. Projectile collisions & clashing
    const projs = effects.projectiles;
    for (let i = projs.length - 1; i >= 0; i--) {
      const pr = projs[i];
      // Check projectile vs projectile clash
      for (let j = i - 1; j >= 0; j--) {
        const other = projs[j];
        if (pr.owner !== other.owner) {
          const dist = Math.hypot(pr.x - other.x, pr.y - other.y);
          if (dist < pr.radius + other.radius) {
            effects.spawnHitSparks((pr.x + other.x) * 0.5, (pr.y + other.y) * 0.5, '#ffffff', 16, true);
            effects.spawnText((pr.x + other.x) * 0.5, pr.y - 26, 'CLASH!', '#ffd147', 1.0);
            audio.playBlock();
            if (!pr.isSuper) pr.hitsLeft = 0;
            if (!other.isSuper) other.hitsLeft = 0;
          }
        }
      }
      if (pr.hitsLeft <= 0 || pr.hitCooldown > 0) continue;

      const target = pr.owner === p1 ? p2 : p1;
      if (target.invulnFrames > 0) continue;
      const hurt = target.getHurtbox();
      const prRect = { x: pr.x - pr.radius, y: pr.y - pr.radius, w: pr.radius * 2, h: pr.radius * 2 };
      if (rectsOverlap(prRect, hurt)) {
        pr.hitsLeft -= 1;
        pr.hitCooldown = 0.14;
        const projMove = {
          damage: pr.damage,
          chipDamage: pr.chipDamage,
          hitstun: pr.isSuper ? 26 : 18,
          blockstun: pr.isSuper ? 16 : 12,
          knockback: pr.isSuper ? 380 : 280,
          launchY: pr.isSuper ? -180 : 0,
          energyGain: 6,
          hitstop: pr.isSuper ? 6 : 5,
          heavy: true,
          isSuper: pr.isSuper,
          projVx: pr.vx
        };
        const res = applyHit(pr.owner, target, projMove, effects, audio, true);
        if (res.hitstop > maxHitstop) maxHitstop = res.hitstop;
      }
    }

    return maxHitstop;
  }

  IF.MOVES = MOVES;
  IF.getWorldHitbox = getWorldHitbox;
  IF.resolveCombat = resolveCombat;
})(window.IronFang = window.IronFang || {});
