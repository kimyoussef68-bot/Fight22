// stages.js - 3 animated HD fighting arenas with parallax, dynamic lighting, and ambient particles
(function (IF) {
  'use strict';

  const STAGES = [
    {
      id: 'neon_rooftop',
      name: 'NEO-TOKYO ROOFTOP',
      subtitle: 'Sector 7 Skydeck • Midnight Rain',
      skyTop: '#080b1c',
      skyMid: '#1a1138',
      skyBot: '#42164a',
      rimColor: 'rgba(0, 240, 255, 0.35)',
      floorTop: '#24293d',
      floorBot: '#111421',
      accent: '#00f0ff',
      secondary: '#ff2bd6'
    },
    {
      id: 'crimson_temple',
      name: 'CRIMSON SHRINE',
      subtitle: 'Mount Aoi Courtyard • Blood Sunset',
      skyTop: '#1c0916',
      skyMid: '#6e1b29',
      skyBot: '#e36434',
      rimColor: 'rgba(255, 165, 80, 0.38)',
      floorTop: '#4a3a35',
      floorBot: '#241b19',
      accent: '#ff7b3a',
      secondary: '#ffd166'
    },
    {
      id: 'cyber_foundry',
      name: 'IRON REACTOR',
      subtitle: 'Volga Heavy Foundry • Core Meltdown',
      skyTop: '#0d1017',
      skyMid: '#241c18',
      skyBot: '#59230e',
      rimColor: 'rgba(255, 180, 40, 0.42)',
      floorTop: '#333842',
      floorBot: '#181b21',
      accent: '#ffaa00',
      secondary: '#ff4800'
    }
  ];

  // Pre-seed deterministic scenery arrays so rendering is fast and flicker-free
  const rainDrops = Array.from({ length: 75 }, (_, i) => ({
    x: (i * 197) % 1280,
    y: (i * 89) % 720,
    len: 14 + (i % 16),
    spd: 520 + (i % 5) * 90
  }));

  const petals = Array.from({ length: 42 }, (_, i) => ({
    x: (i * 151) % 1280,
    y: (i * 67) % 580,
    size: 4 + (i % 5),
    phase: i * 0.7,
    spdX: -40 - (i % 4) * 18,
    spdY: 28 + (i % 3) * 16
  }));

  const embers = Array.from({ length: 55 }, (_, i) => ({
    x: (i * 137) % 1280,
    y: (i * 97) % 720,
    r: 1.5 + (i % 3) * 1.1,
    spdY: -55 - (i % 5) * 28,
    drift: (i % 7) - 3
  }));

  function renderStage(ctx, stageId, w, h, groundY, time, cameraX) {
    const stage = STAGES.find(s => s.id === stageId) || STAGES[0];
    const par1 = -cameraX * 0.12;
    const par2 = -cameraX * 0.28;
    const par3 = -cameraX * 0.52;

    // Sky gradient
    const sky = ctx.createLinearGradient(0, 0, 0, groundY);
    sky.addColorStop(0, stage.skyTop);
    sky.addColorStop(0.58, stage.skyMid);
    sky.addColorStop(1, stage.skyBot);
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, groundY);

    if (stage.id === 'neon_rooftop') {
      drawNeonRooftop(ctx, w, h, groundY, time, par1, par2, par3);
    } else if (stage.id === 'crimson_temple') {
      drawCrimsonTemple(ctx, w, h, groundY, time, par1, par2, par3);
    } else {
      drawCyberFoundry(ctx, w, h, groundY, time, par1, par2, par3);
    }

    // Floor with perspective grid / stone tiles
    const floorGrad = ctx.createLinearGradient(0, groundY, 0, h);
    floorGrad.addColorStop(0, stage.floorTop);
    floorGrad.addColorStop(0.18, stage.floorBot);
    floorGrad.addColorStop(1, '#08090f');
    ctx.fillStyle = floorGrad;
    ctx.fillRect(0, groundY, w, h - groundY);

    // Stage floor highlight strip
    ctx.fillStyle = stage.accent;
    ctx.globalAlpha = 0.45;
    ctx.fillRect(0, groundY, w, 3);
    ctx.globalAlpha = 1;

    // Perspective floor lines
    ctx.save();
    ctx.strokeStyle = 'rgba(255,255,255,0.09)';
    ctx.lineWidth = 1.5;
    const centerX = w * 0.5 - cameraX * 0.6;
    for (let i = -10; i <= 10; i++) {
      const topX = centerX + i * 95;
      const botX = centerX + i * 190;
      ctx.beginPath();
      ctx.moveTo(topX, groundY);
      ctx.lineTo(botX, h);
      ctx.stroke();
    }
    for (let j = 1; j <= 4; j++) {
      const y = groundY + Math.pow(j / 4, 1.5) * (h - groundY);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawNeonRooftop(ctx, w, h, groundY, time, par1, par2, par3) {
    // Distant moon & glowing haze
    const moonX = w * 0.72 + par1 * 0.3;
    const moonY = 125;
    const glow = ctx.createRadialGradient(moonX, moonY, 12, moonX, moonY, 170);
    glow.addColorStop(0, 'rgba(220, 240, 255, 0.95)');
    glow.addColorStop(0.28, 'rgba(130, 170, 255, 0.35)');
    glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(moonX, moonY, 170, 0, Math.PI * 2);
    ctx.fill();

    // Far skyline silhouette
    ctx.fillStyle = '#0f122b';
    for (let i = -2; i < 16; i++) {
      const bx = i * 105 + par1;
      const bh = 160 + ((i * 53) % 150);
      const bw = 78 + ((i * 29) % 34);
      ctx.fillRect(bx, groundY - bh, bw, bh);
      // Tiny lit windows
      ctx.fillStyle = i % 2 === 0 ? 'rgba(0,240,255,0.22)' : 'rgba(255,43,214,0.2)';
      for (let wy = groundY - bh + 14; wy < groundY - 30; wy += 18) {
        if (((wy + i * 13) % 3) !== 0) {
          ctx.fillRect(bx + 10, wy, bw - 20, 5);
        }
      }
      ctx.fillStyle = '#0f122b';
    }

    // Mid-layer skyscrapers with animated neon billboards
    for (let i = -1; i < 9; i++) {
      const bx = i * 185 + par2;
      const bh = 210 + ((i * 71) % 140);
      const bw = 115;
      ctx.fillStyle = '#151936';
      ctx.fillRect(bx, groundY - bh, bw, bh);

      // Animated neon sign
      const pulse = 0.65 + 0.35 * Math.sin(time * 3.5 + i * 1.4);
      ctx.save();
      ctx.globalAlpha = pulse;
      ctx.fillStyle = i % 2 === 0 ? '#00f0ff' : '#ff2bd6';
      ctx.shadowColor = ctx.fillStyle;
      ctx.shadowBlur = 16;
      ctx.fillRect(bx + 14, groundY - bh + 28, bw - 28, 12);
      ctx.fillRect(bx + 24, groundY - bh + 52, bw - 48, 6);
      ctx.restore();
    }

    // Searchlight beams sweeping the sky
    ctx.save();
    for (let s = 0; s < 2; s++) {
      const originX = (s === 0 ? w * 0.25 : w * 0.78) + par2;
      const angle = Math.sin(time * 0.65 + s * 2.1) * 0.45 - Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(originX, groundY);
      ctx.lineTo(originX + Math.cos(angle - 0.08) * 620, groundY + Math.sin(angle - 0.08) * 620);
      ctx.lineTo(originX + Math.cos(angle + 0.08) * 620, groundY + Math.sin(angle + 0.08) * 620);
      ctx.closePath();
      ctx.fillStyle = s === 0 ? 'rgba(0, 240, 255, 0.07)' : 'rgba(255, 43, 214, 0.07)';
      ctx.fill();
    }
    ctx.restore();

    // Rooftop safety railing
    ctx.strokeStyle = '#333b5c';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(0, groundY - 46);
    ctx.lineTo(w, groundY - 46);
    ctx.moveTo(0, groundY - 22);
    ctx.lineTo(w, groundY - 22);
    ctx.stroke();
    for (let rx = (par3 % 90) - 90; rx < w + 90; rx += 90) {
      ctx.beginPath();
      ctx.moveTo(rx, groundY - 50);
      ctx.lineTo(rx, groundY);
      ctx.stroke();
    }

    // Animated diagonal rain
    ctx.strokeStyle = 'rgba(155, 225, 255, 0.32)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    for (let i = 0; i < rainDrops.length; i++) {
      const r = rainDrops[i];
      const ry = (r.y + time * r.spd) % groundY;
      const rx = (r.x - time * 90 + w * 4) % w;
      ctx.moveTo(rx, ry);
      ctx.lineTo(rx - 4, ry + r.len);
    }
    ctx.stroke();
  }

  function drawCrimsonTemple(ctx, w, h, groundY, time, par1, par2, par3) {
    // Giant sunset sun
    const sunX = w * 0.5 + par1 * 0.4;
    const sunY = groundY - 110;
    const sunGrad = ctx.createRadialGradient(sunX, sunY, 20, sunX, sunY, 220);
    sunGrad.addColorStop(0, '#fff2b2');
    sunGrad.addColorStop(0.35, '#ff8e3c');
    sunGrad.addColorStop(0.7, 'rgba(227, 68, 45, 0.25)');
    sunGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(sunX, sunY, 220, 0, Math.PI * 2);
    ctx.fill();

    // Distant mountain ridge
    ctx.fillStyle = '#33121e';
    ctx.beginPath();
    ctx.moveTo(0, groundY);
    for (let x = 0; x <= w + 80; x += 80) {
      const mh = 95 + Math.sin((x - par1) * 0.008) * 55 + Math.cos((x - par1) * 0.017) * 35;
      ctx.lineTo(x, groundY - mh);
    }
    ctx.lineTo(w, groundY);
    ctx.closePath();
    ctx.fill();

    // Iconic Torii gate in midground
    const tx = w * 0.5 + par2;
    ctx.fillStyle = '#8f1d24';
    ctx.fillRect(tx - 150, groundY - 230, 26, 230);
    ctx.fillRect(tx + 124, groundY - 230, 26, 230);
    // Top curved beam
    ctx.fillStyle = '#b3242b';
    ctx.fillRect(tx - 205, groundY - 246, 410, 24);
    ctx.fillStyle = '#1e1015';
    ctx.fillRect(tx - 215, groundY - 254, 430, 12);
    ctx.fillStyle = '#991f26';
    ctx.fillRect(tx - 172, groundY - 188, 344, 16);
    // Center plaque
    ctx.fillStyle = '#1e1015';
    ctx.fillRect(tx - 22, groundY - 232, 44, 52);
    ctx.fillStyle = '#ffd166';
    ctx.fillRect(tx - 12, groundY - 222, 24, 32);

    // Stone lanterns with flickering firelight
    const lanterns = [w * 0.16 + par3, w * 0.84 + par3];
    for (let i = 0; i < lanterns.length; i++) {
      const lx = lanterns[i];
      ctx.fillStyle = '#3a2c2b';
      ctx.fillRect(lx - 14, groundY - 95, 28, 95);
      ctx.fillRect(lx - 26, groundY - 125, 52, 16);
      const flick = 0.75 + 0.25 * Math.sin(time * 9 + i * 3);
      const lg = ctx.createRadialGradient(lx, groundY - 102, 4, lx, groundY - 102, 75);
      lg.addColorStop(0, `rgba(255, 220, 110, ${0.9 * flick})`);
      lg.addColorStop(0.5, `rgba(255, 110, 40, ${0.35 * flick})`);
      lg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = lg;
      ctx.beginPath();
      ctx.arc(lx, groundY - 102, 75, 0, Math.PI * 2);
      ctx.fill();
    }

    // Drifting sakura petals
    ctx.fillStyle = '#ffb3c6';
    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      const px = (p.x + time * p.spdX + Math.sin(time * 2 + p.phase) * 24 + w * 4) % w;
      const py = (p.y + time * p.spdY) % groundY;
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(time * 1.8 + p.phase);
      ctx.beginPath();
      ctx.ellipse(0, 0, p.size, p.size * 0.55, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  function drawCyberFoundry(ctx, w, h, groundY, time, par1, par2, par3) {
    // Massive glowing reactor core in background
    const cx = w * 0.5 + par1;
    const cy = groundY - 185;
    const pulse = 0.85 + 0.15 * Math.sin(time * 4.2);
    const coreGrad = ctx.createRadialGradient(cx, cy, 18, cx, cy, 240 * pulse);
    coreGrad.addColorStop(0, '#fff7cc');
    coreGrad.addColorStop(0.25, '#ffaa00');
    coreGrad.addColorStop(0.6, 'rgba(255, 64, 0, 0.35)');
    coreGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = coreGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, 240 * pulse, 0, Math.PI * 2);
    ctx.fill();

    // Rotating industrial turbine rings
    ctx.save();
    ctx.translate(cx, cy);
    ctx.strokeStyle = 'rgba(40, 44, 54, 0.9)';
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.arc(0, 0, 120, 0, Math.PI * 2);
    ctx.stroke();
    ctx.rotate(time * 0.6);
    for (let k = 0; k < 8; k++) {
      ctx.rotate(Math.PI / 4);
      ctx.fillStyle = '#252932';
      ctx.fillRect(-10, -135, 20, 38);
    }
    ctx.restore();

    // Heavy steel girders & molten pipes
    ctx.fillStyle = '#1b1f27';
    for (let i = 0; i < 5; i++) {
      const gx = i * 310 - 60 + par2;
      ctx.fillRect(gx, 0, 44, groundY);
      // Hazard stripes
      ctx.fillStyle = '#d98a00';
      ctx.fillRect(gx + 6, groundY - 75, 32, 10);
      ctx.fillRect(gx + 6, groundY - 55, 32, 10);
      ctx.fillStyle = '#1b1f27';
    }

    // Horizontal catwalk truss
    ctx.fillStyle = '#242934';
    ctx.fillRect(0, groundY - 310, w, 18);
    ctx.fillStyle = 'rgba(255, 130, 20, 0.55)';
    ctx.fillRect(0, groundY - 292, w, 3);

    // Rising glowing embers
    for (let i = 0; i < embers.length; i++) {
      const e = embers[i];
      const ey = (e.y + time * e.spdY + groundY * 4) % groundY;
      const ex = (e.x + Math.sin(time * 3 + i) * 18 + e.drift * time * 5 + w * 4) % w;
      ctx.fillStyle = i % 2 === 0 ? '#ffcc33' : '#ff5511';
      ctx.beginPath();
      ctx.arc(ex, ey, e.r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  IF.STAGES = STAGES;
  IF.renderStage = renderStage;
})(window.IronFang = window.IronFang || {});
